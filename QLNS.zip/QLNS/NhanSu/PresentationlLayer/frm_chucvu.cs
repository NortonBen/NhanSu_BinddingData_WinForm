﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NhanSu.PersentationlLayer
{
    public partial class frm_chucvu : Form
    {
        public frm_chucvu()
        {
            InitializeComponent();
        }
    }
}
